var _ = require('underscore');
var arr = [3,6,8,1,12];

console.log(arr[0]);
console.log(_.first(arr));
console.log(_.last(arr));
